#!/bin/bash
# Whether the compile of vxc before each run changes the decode time of the app on this fanless Mac:
# runs of vxc (compile, then run) alternate with runs of one executable that vxc linked before.
S=/private/tmp/claude-501/-Users-adityak-go-Vx/c9563366-f5fa-4315-b7c9-8bab3e715bf5/scratchpad
V=/private/tmp/claude-501/-Users-adityak-go-qwen-vx/8958e885-de1c-4307-9326-21acf40e275c/scratchpad/vxhome/.vx/toolchains/v0.0.5
Q=$HOME/go/qwen-vx-bench
O=$S/compile-heat
mkdir -p "$O"
f=$Q/docs/benchmarks/qwen36-m4/prompts/context/vx/ctx512.txt
args=("$HOME/models/Qwen3.6-35B-A3B-q4-q6.vxw" --tokenizer "$HOME/models/Qwen3.6-35B-A3B.vxt" --prompt-file "$f" --steps 256 --ignore-eos)
jit() { "$V/bin/vxc" -O2 "$Q/src/main.vx" --package qwen="$Q/src" --host default --machine "$V/fleet/m4-uma.vx" -- "${args[@]}"; }
CLANG_PATH=$S/keep-exe/clang KEEP_EXE=$O/app jit > "$O/keep.txt" 2>&1
ls -la "$O/app" || exit 1
for r in 1 2 3; do
  sleep 30
  jit > "$O/jit.r$r.txt" 2>&1
  sleep 30
  "$O/app" "${args[@]}" > "$O/exe.r$r.txt" 2>&1
done
grep -H 'time ms_per_token' "$O"/*.txt
