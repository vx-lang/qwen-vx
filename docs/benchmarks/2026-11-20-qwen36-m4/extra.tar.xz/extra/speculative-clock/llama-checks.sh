#!/bin/bash
# Two checks of llama.cpp on Qwen3.6, before the benchmark: the text of ngram-cache drafts, and the
# prompt clock of llama-speculative-simple with and without llama_synchronize.
S=/private/tmp/claude-501/-Users-adityak-go-Vx/c9563366-f5fa-4315-b7c9-8bab3e715bf5/scratchpad
B=$S/llama-src/build/bin
P=$HOME/go/qwen-vx-bench/docs/benchmarks/qwen36-m4/prompts/twelve/llama
G=$HOME/models/gguf/qwen36/Qwen3.6-35B-A3B-Q4_0.gguf
O=$S/llama-checks
mkdir -p "$O"
common=(-m "$G" -c 8192 --temp 0 -ngl 99 -fa on --no-escape --ignore-eos)
for n in write1 edit1; do
  sleep 10
  "$B/llama-completion" "${common[@]}" -f "$P/$n.txt" -n 128 -no-cnv > "$O/$n.completion.txt" 2>&1
  sleep 10
  "$B/llama-speculative-simple" "${common[@]}" -f "$P/$n.txt" -n 128 --spec-type ngram-cache --spec-draft-n-max 8 > "$O/$n.cache8.txt" 2>&1
done
for r in 1 2; do
  for v in orig patched; do
    exe=$B/llama-speculative-simple
    [ $v = orig ] && exe=$exe.orig
    sleep 10
    "$exe" "${common[@]}" -f "$P/edit1.txt" -n 128 --spec-type ngram-mod > "$O/edit1.ngram.$v.r$r.txt" 2>&1
  done
done
echo done
